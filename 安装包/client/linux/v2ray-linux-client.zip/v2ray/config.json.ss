{
  "inbounds": [
    {
      "port": 1080,                   // 本地监听的端口，通常是SOCKS5代理端口
      //"listen": "127.0.0.1",          // 只允许本地访问
      "listen": "0.0.0.0",          // 只允许本地访问
      "protocol": "socks",            // 代理协议
      "settings": {
        "auth": "noauth",             // 不需要认证
        "udp": false,                 // 是否启用UDP
        "ip": "127.0.0.1"
      }
    }
  ],

  "outbounds": [
        {
            "protocol": "shadowsocks",
            "settings": {
                "servers": [
                    {
                        "address": "127.0.0.1", // Replace with the actual SS server address
                        "port": 10086,
                        "method": "AEAD_CHACHA20_POLY1305",
                        "password": "123456",
                        "level": 0,
                        "ota": false
                    }
                ]
            },
            "streamSettings": {
                "network": "tcp"
            }
        }
    ],



  "dns": {
    "servers": [
      "8.8.8.8",                      // 使用 Google DNS
      "8.8.4.4"
    ]
  },
  "routing": {
    "rules": [
      {
        "type": "field",
        "outboundTag": "direct",
        "ip": ["geoip:private"]       // 直连内网流量
      }
    ]
  }
}

