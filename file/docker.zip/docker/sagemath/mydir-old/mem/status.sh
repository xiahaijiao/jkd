grep "success" data.txt
