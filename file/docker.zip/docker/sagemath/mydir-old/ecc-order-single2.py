# !/usr/bin/env sage
import sys
import time

from sage.all import *

start_num = 13
count = 1000

a = 0
b = 7

a = -27
b = 46710
# count = 31069

# start_num = 31069
# count = 1000000

# start_num = 8589247
# start_num = 10242637
# count = 10000000
end_num = start_num + count


def cal(start_num, end_num):
    index_num = 0
    while start_num < end_num:

        p = start_num

        if p >= 1000:
            break

        if is_prime(p):

            discriminant = -16 * (4 * a ** 3 + 27 * b ** 2)
            discriminant = discriminant % p
            if discriminant == 0:
                # print("错误：参数导致奇异曲线，请修改a或b")
                continue
            else:
                # print("曲线有效")
                pass

                n = EllipticCurve(GF(p), [a, b]).order()
                if is_prime(n):
                    pass
                    p_1 = factor(p - 1)
                    n_1 = factor(n - 1)
                    print("p=", p, ",n=", n, "; p-1=", p_1, " \t \t,n_1=", n_1)
                    # if p == n:
                    #     print("p=", p, ",n=", n, "; p-1=", p_1, " \t \t,n_1=", n_1)
                    #     pass

        #                 print("p=", p, ",n=", n, "; p-1=", p_1, " \t \t,n_1=", n_1)

        start_num = start_num + 1

    pass


# start_num = 96661
# count = 1000000

start_num = 13
count = 10000

end_num = start_num + count

cal(start_num, end_num)
