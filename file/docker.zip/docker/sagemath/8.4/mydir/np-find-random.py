
#!/usr/bin/env sage
import sys
import time

from sage.all import *
import random


start_num = 8589247
start_num = 10242637
count = 10000000
end_num = start_num + count

def cal(start_num,end_num):
    index_num = 0
    while start_num < end_num:
        p = start_num
        if is_prime(p):
            n = EllipticCurve(GF(p), [0, 7]).order()
            if is_prime(n):
                print("p=", p, ",n=", n)
                if p==n:
                    print("p=", p, ",n=", n)
                    print("-------------- success p=n ",p,n)
#                    break
                pass
#                 p_1 = factor(p - 1)
#                 n_1 = factor(n - 1)
#                 print("p=", p, ",n=", n, "; p-1=", p_1, " \t \t,n_1=", n_1)

        start_num = start_num + 1

    pass

start_num = 107361793816595537
start_num = 123230573852164273674364426950
start_num = 123230573852164273674376029967
start_num = 1000000000000000
start_num = 100000000000
import random



count = 10000000

# start_num = 13
# count = 100


end_num = start_num + count
while 1 :
    random_int = random.randint(1000000000000000, 10000000000000000)
    print(random_int)
    start_num = random_int
    end_num = start_num + count

    cal(start_num,end_num)
    start_num = end_num
    end_num = start_num + count
    print("-----------------start-------------------------",start_num)
    time.sleep(3)
#    break
