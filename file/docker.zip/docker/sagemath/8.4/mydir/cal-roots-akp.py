# !/usr/bin/env sage
import sys
import time

from sage.all import *
import random

from flask import Flask, request, jsonify
import ast

debug=false





# 模为大合数，高次剩余

def compute_chinese(p_array, a_arrays):
    marray = []
    for combinations in a_arrays:
        combinations = list(combinations)
        result = crt(combinations, p_array)
        marray.append(result)
        pass
    #     print(marray)
    marray.sort()
    #     print(marray)
    return marray

    pass


def compute_single_primitive(k, p):
    my_ring = GF(p)
    my_a = my_ring(1)
    my_x = my_a.nth_root(k)
    marray = []
    for i in range(0, k):
        temp = power_mod(my_x, i, p)
        marray.append(temp)
    #     print(marray)
    return marray
    pass


def compute_single_p(a, k, p):
    a=int(a)
    k=int(k)
    p=int(p)
    # print(f'---------{a,k,p},{type(p)}')
    # my_ring2 = GF(13)
    # print(my_ring2)
    my_ring = GF(p)
    # print(f'---------{my_ring}')

    my_a = my_ring(a)
    my_x = my_a.nth_root(k)
    primitive_array = compute_single_primitive(k, p)
    marray = []
    for item in primitive_array:
        temp = item * my_x % p
        temp = int(temp)
        marray.append(temp)
        pass
    marray.sort()
    return marray


def cal_combinations(arrays):
    from itertools import product

    # 给定数组列表
    #     arrays = [[5, 8], [7, 36]]
    #     arrays=[[5, 8], [7, 36], [17, 44], [10684, 20385]]

    # 生成所有组合
    combinations = list(product(*arrays))

    #     print(combinations)

    return combinations
    pass


def cal_mulitpy_p(a, k, p):
    factors = factor(p)

    # 将素因子数组转换为列表
    factors_list = list(factors)

    # 打印结果
    # print(factors_list)
    p_array = []
    a_arrays = []
    for item in factors_list:
        p1 = item[0]
        k1 = item[1]
        if k1 >= 2:
            print("error", factors_list)
            return -1
            break
        res_a = compute_single_p(a, k, p1)

        a_arrays.append(res_a)
        # print(p1, res_a)
        p_array.append(p1)
    p_array.sort()
    combinations = cal_combinations(a_arrays)
    # print(p_array)
    # print(a_arrays)
    # print(combinations)

    # print(p)
    res_roots = compute_chinese(p_array, combinations)
    # print(res_roots)
    return (p_array, a_arrays, res_roots)

    pass



# a=350
# k=2
# p=13
a=sys.argv[1]
k=sys.argv[2]
p=sys.argv[3]
a=int(a)
k=int(k)
p=int(p)
res=cal_mulitpy_p(a, k, p)
print(res)

