mkdir -p mydir
chmod 777 -R mydir
docker-compose -f docker-compose.yml up -d
