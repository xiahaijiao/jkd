
mkdir -p /etc/dae/
cp config.dae /etc/dae/config.dae
chmod 600 /etc/dae/config.dae

# lan_interface 需要设置
# 内核版本  内核大于5.17  ；centos8.2  v4.18



#debian 12 :  6.1.0-32-amd64
#debian 11: 5.10

# 或许需要
vim /etc/sysctl.conf
net.ipv4.ip_forward=1
net.ipv6.conf.all.forwarding=1

sysctl -p





img=xiahaijiao/h-shgroup:dae
#img=daeuniverse/dae:latest
  docker run -d     \
  --restart always     \
  --network host     \
  --pid host     --privileged     \
  -v /sys:/sys     -v /etc/dae:/etc/dae     \
  --name dae     $img




#测试
 curl ipinfo.io/json
