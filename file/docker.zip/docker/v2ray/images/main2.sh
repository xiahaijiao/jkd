
#!/bin/bash
cd /root
cp -f /usr/share/nginx/html/index.html.default /usr/share/nginx/html/index.html
sh /root/ip.sh
#source ~/.bashrc

dir=`pwd`
cd /root/socket/
sh run.sh
cd /root/v2ray/bin
sh run.sh
cd $dir
sh /root/vn.sh

/usr/sbin/crond

index=1
/usr/sbin/nginx -c /etc/nginx/nginx.conf
while [ 1 ]
do
        date
        echo $index
echo "<br>[$index] -" >>/usr/share/nginx/html/index.html
date >>/usr/share/nginx/html/index.html
sh /root/vn-day.sh
	let index++
        sleep 86400

done
