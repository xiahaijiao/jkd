
response=$(curl -s https://ipinfo.io/)
echo -e "\n<pre>\n$response\n</pre>" >> /usr/share/nginx/html/index.html

