
rm xiahaijiao.eu.org -fr
unzip xiahaijiao.eu.org.zip
docker cp xiahaijiao.eu.org v2ray-shadowsocks:/etc/nginx/conf.d/cert/
docker cp xiahaijiao.eu.org/cert.crt v2ray-shadowsocks:/etc/nginx/conf.d/cert/
docker cp xiahaijiao.eu.org/private.key v2ray-shadowsocks:/etc/nginx/conf.d/cert/


echo "--------- 进入容器 "
docker exec -it v2ray-shadowsocks bash
echo -e "
nginx  -t
nginx  -s reload
"
