

#安装  https://docs.cloud.google.com/sdk/docs/install-sdk?hl=zh-cn#linux
curl -O https://dl.google.com/dl/cloudsdk/channels/rapid/downloads/google-cloud-cli-linux-x86_64.tar.gz
tar -xf google-cloud-cli-linux-x86_64.tar.gz
./google-cloud-sdk/install.sh
./google-cloud-sdk/install.sh --help
#配置变量
vi ~/.bashrc
export PATH="$PATH:/root/google-cloud-sdk/bin"
source ~/.bashrc

#初始化
gcloud init

#登录ssh

gcloud compute ssh xiahaijiao2@instance-20260120-usa \
    --zone "us-central1-c" \
    --project "project-19464c1d-74b2-44e6-95f"










sudo apt-get remove --purge google-cloud-ops-agent -y
sudo apt-get remove --purge google-osconfig-agent -y
sudo apt-get remove --purge google-guest-agent -y
sudo apt-get autoremove -y
sudo apt-get remove --purge packagekit packagekit-tools -y

apt-get remove --purge haveged -y
apt-get remove --purge dbus -y
apt-get remove --purge policykit-1 -y
apt-get remove --purge exim4* -y
apt-get remove --purge unattended-upgrades -y



sudo systemctl stop google-guest-agent
sudo systemctl disable google-guest-agent
sudo apt-get remove --purge google-guest-agent -y
sudo apt-get remove --purge google-guest-agent -y
sudo apt-get autoremove -y

systemctl stop google-osconfig-agent google-guest-agent
systemctl disable google-osconfig-agent google-guest-agent
apt remove --purge google-osconfig-agent google-guest-agent -y




sudo apt-get autoremove --purge -y
sudo apt-get clean




systemctl stop google-osconfig-agent google-guest-agent
systemctl disable google-osconfig-agent google-guest-agent
apt remove --purge google-osconfig-agent google-guest-agent -y
apt remove --purge unattended-upgrades -y
apt remove --purge networkd-dispatcher -y
apt remove --purge exim4* -y
apt remove --purge policykit-1 -y
apt remove --purge dbus -y
apt remove --purge rsyslog -y
apt remove --purge google-osconfig-agent google-guest-agent unattended-upgrades networkd-dispatcher exim4* policykit-1 dbus rsyslog     -y
apt autoremove --purge -y






