img="pengzhile/pandora"
img="xiahaijiao/h-shgroup:pandora"
#docker run --name=pandora  -e PANDORA_CLOUD=cloud -e PANDORA_SERVER=0.0.0.0:8899 -p 8899:8899 -d pengzhile/pandora
docker run --name=pandora  -e PANDORA_CLOUD=cloud -e PANDORA_SERVER=0.0.0.0:8899 -p 10090:8899 -d $img
